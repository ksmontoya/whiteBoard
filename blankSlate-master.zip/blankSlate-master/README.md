# BlankSlate
Code for a robot that draws on a whiteboard
