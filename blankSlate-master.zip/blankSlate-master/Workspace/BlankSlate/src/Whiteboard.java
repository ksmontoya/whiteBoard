import java.awt.Point;
import org.zu.ardulink.Link;

/**
 * 
 * @author arnoldo
 *-Use keypads to send commands to arduino.
 *move up, down, left, right.
 *
 *In Constructor
 		Initialize arduino, set up to 
 		send messages
 */


public class Whiteboard {
	public Point getLocation()
	{
		return null;
	}
	
	public boolean calibrate()
	{
		return false;
	}
	
	public void penUp()
	{
		
	}
	
	public void penDown()
	{
		
	}
	
	public void setXY(Point point)
	{
		
	}
}
